
const VideoComp = ({}) => {
    return (
      <div>
        <img
          className="avatar-img"
          src="https://img.freepik.com/premium-photo/young-handsome-man-with-beard-isolated-keeping-arms-crossed-frontal-position_1368-132662.jpg"
        />
        <div>
          <p className="avatar-name">Trac Do</p>
          <p className="job-type">Solutions Architect</p>
        </div>
      </div>
    );
  };

  export default VideoComp;
  
 